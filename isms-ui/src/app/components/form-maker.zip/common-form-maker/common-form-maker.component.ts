import {AfterViewInit, ChangeDetectorRef, Component, Input, OnInit} from '@angular/core';
import {BehaviorSubject} from "rxjs";
import {AjaxCallService} from "../../services/ajax-call.service";
import {GeneralStateService} from "../../services/general-state.service";
import {ActivatedRoute} from "@angular/router";
import {CdkDragDrop, copyArrayItem, moveItemInArray} from "@angular/cdk/drag-drop";

@Component({
  selector: 'app-common-form-maker',
  templateUrl: './common-form-maker.component.html',
  styleUrls: ['./common-form-maker.component.css'],
  animations: [],
})
export class CommonFormMakerComponent implements OnInit, AfterViewInit {
  Object = Object;

  newContainer() {
    console.log(JSON.stringify(this.model))
    this.model[Object.keys(this.model).length + 1] = [];
    this.modelSubject.next(this.model)
  }

  model = {
  };

  modelSubject = new BehaviorSubject<any>(this.model);

  items = [
    'Layout',
    'Text',
    'Number',
    'Date',
    'Select',
    'Multi-Select',
    'Checkbox',
    'Radio'
  ];

  basket = [
  ];

  drop(event: CdkDragDrop<string[]>) {
    console.log(event, event.previousContainer, event.container);
    console.log(event.previousContainer.data.length, event.container.data.length);
    if(event.container.data.length < 1) {
      if (event.previousContainer === event.container) {
        console.log("1")
        moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      } else {
        console.log("2")

        copyArrayItem(event.previousContainer.data,
          event.container.data,
          event.previousIndex,
          event.currentIndex);
        // transferArrayItem(event.previousContainer.data,
        //   event.container.data,
        //   event.previousIndex,
        //   event.currentIndex);
      }
    } else {
      event.container.data.length = 0;
      copyArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
    }
  }

  @Input() url: string;
  processedUrl: string;

  config: object = null;
  configSubject: BehaviorSubject<object> = new BehaviorSubject<object>(this.config);

  values: object = null;
  valuesSubject: BehaviorSubject<object> = new BehaviorSubject<object>(this.values);



  constructor(private cdr: ChangeDetectorRef,
              private route: ActivatedRoute,
              private ajaxCallService: AjaxCallService,
              private generalStateService: GeneralStateService) {
    this.generalStateService.title = "";
  }

  ngAfterViewInit(): void {
    this.model['item1'] = [];
    this.modelSubject.next(this.model);
  }

  async ngOnInit() {
    this.route.params.subscribe(params => {
      this.url = params['url'];
      for (let k in this.model) {
          delete this.model[k];
      }
    });
  }

  setValue(layout) {
    console.log(layout)
    for (let c of layout) {
      console.log(c)
      if (!c.hasOwnProperty('type') || c['type'] == 'layout') {
        if (c.hasOwnProperty('children'))
          this.setValue(c['children']);
        else if (c.hasOwnProperty('layout'))
          this.setValue(c['layout']);
      } else {
        if(c.hasOwnProperty('field') && c.hasOwnProperty('value')) {
          this.model[c['field']] = c['value'];
        }
      }
    }
  }

  btnClick(e) {
  }

  search() {
  }
}
